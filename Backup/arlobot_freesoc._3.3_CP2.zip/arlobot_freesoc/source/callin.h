#ifndef CALIN_H
#define CALIN_H
    
#include <project.h>    

void PerformLinearBiasCalibration(uint8 verbose);

#endif    