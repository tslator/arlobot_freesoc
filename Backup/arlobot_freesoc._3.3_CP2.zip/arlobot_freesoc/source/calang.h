#ifndef CALANG_H
#define CALANG_H
    
#include <project.h>    
    
void PerformAngularBiasCalibration(uint8 verbose);
    
#endif