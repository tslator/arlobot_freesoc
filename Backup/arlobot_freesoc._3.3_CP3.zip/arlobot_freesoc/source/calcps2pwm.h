#ifndef CALCPS2PWM_H
#define CALCPS2PWM_H
    
#include <project.h>
    
void PerformCountPerSecToPwmCalibration(uint8 verbose);    
    
#endif    